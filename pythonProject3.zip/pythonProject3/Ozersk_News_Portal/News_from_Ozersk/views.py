from datetime import datetime
from django.views.generic import ListView, DetailView
from .models import New


class NewsList(ListView):

    model = New                     # Указываем модель, объекты которой мы будем выводить
    ordering = '-time_in'                # Поле, которое будет использоваться для сортировки объектов
    template_name = 'news.html'      # Указываем имя шаблона, в котором будут все инструкции о том,
                                     # как именно пользователю должны быть показаны наши объекты
    context_object_name = 'news'     # Это имя списка, в котором будут лежать все объекты.
                                     # Его надо указать, чтобы обратиться к списку объектов в html-шаблоне.
    def get_context_data(self, **kwargs):
        # С помощью super() мы обращаемся к родительским классам
        # и вызываем у них метод get_context_data с теми же аргументами,
        # что и были переданы нам.
        # В ответе мы должны получить словарь.
        context = super().get_context_data(**kwargs)
        # К словарю добавим текущую дату в ключ 'time_now'.
        context['time_now'] = datetime.utcnow()
        # Добавим ещё одну пустую переменную,
        # чтобы на её примере рассмотреть работу ещё одного фильтра.
        context['next_sale'] = None
        return context

class NewDetail(DetailView):
    # Модель всё та же, но мы хотим получать информацию по отдельному товару
    model = New
    # Используем другой шаблон — product.html
    template_name = 'new.html'
    # Название объекта, в котором будет выбранный пользователем продукт
    context_object_name = 'new'